Haga click aquí para restablecer su contraseña: {{ url('password/reset/'.$token) }}
