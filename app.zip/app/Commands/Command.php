<?php namespace app\Commands;

abstract class Command {

	//

}
