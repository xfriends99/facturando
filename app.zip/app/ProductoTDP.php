<?php namespace app;

use Illuminate\Database\Eloquent\Model;

class ProductoTDP extends Model
{

        protected $table = 'productosTDP';

        public $timestamps = false;

	
}