<?php namespace app;

use Illuminate\Database\Eloquent\Model;

class Corredor extends Model
{           
        protected $table = 'corredores';
	
        public $timestamps = false;

}