{{$msj}}
<p>Gracias por utilizar Facturando!</p>