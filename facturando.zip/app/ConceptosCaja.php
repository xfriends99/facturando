<?php namespace app;

use Illuminate\Database\Eloquent\Model;

class ConceptosCaja extends Model
{
        
	protected $table = 'conceptos_caja';
        public $timestamps = false;
	

	
}