<?php namespace app;

use Illuminate\Database\Eloquent\Model;

class ConceptosCajaEspecial extends Model
{
        
	protected $table = 'conceptos_caja_especial';
        public $timestamps = false;
	

	
}